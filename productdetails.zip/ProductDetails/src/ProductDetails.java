

public class ProductDetails {

	public static void main(String[] args) {
	
       product pro =new product("Easy 2 Go Corner Computer Desk ","$94.99","24343773","WE-OF-0152G","Corner computer desk"," Laminate, gray finish\r\n "+" 30.39\"H x 47.83\"W x 47.83\"D");
       product pro1 =new product("Quill Brand�","$28.99","901-745215","MPNY3AM/A","Recycled Hanging File Folders","Standard green 11 pt. stock");
       product pro2 =new product("Apple AirPods ","$173.99","901-24543634","d884fsc755s4d","Bluetooth Earbuds","Quick access to Siri by saying �Hey Siri�");
       product pro3 =new product("iTouchless","$34.99","901-24531218"," PS01RSS","Trash Can with Hinged Lid","Made of stainless steel");
       product pro4 =new product("APC� ","$25.99","901-2667485","4734031","electronic equipment","Cable length: 6'");
       product pro5 =new product("Union & Scale","$89.99","24448589","UN59378|"," Fabric Swivel Task Chair","Task chair with adjustable height for comfortable office work");
       product pro6 =new product("Dell G15","$1,189.00","5510","i5-10200H ","Gaming Laptop","Intel Core i5");
       product pro7 =new product("Dell","$1,399.99","6800H","null","Gaming Laptop","AMD Ryzen 7, AMD Ryzen");
       product pro8 =new product("Dell Alienware","$2,249.00","10870H","m15 R4 RTX 3070","Gaming Laptop","Intel Core i7");
       product pro9 =new product("Epson WorkForce Pro","$99.99","901-24460293"," C11CJ06201","Color All-in-One Inkjet Printer ","Features 250-sheet input capacity");

       pro.display();
       System.out.println();
       pro1.display();
       System.out.println();
       pro2.display();
       System.out.println();
       pro3.display();
       System.out.println();
       pro4.display();
       System.out.println();
       pro5.display();
       System.out.println();
       pro6.display();
       System.out.println();
       pro7.display();
       System.out.println();
       pro8.display();
       System.out.println();
       pro9.display();



	}

}

class product{
	public String proname;
	public String proprice;
	public String iteamnum;
	public String modelnumber;
	public String procategory;
	public String prodescription;
	
	 public product(String proname,String proprice,String iteamnum,String modelnumber,String procategory,String prodescription){
		 this.proname=proname;
		 this.proprice=proprice;
		 this.iteamnum=iteamnum;
		 this.modelnumber=modelnumber;
		 this.procategory=procategory;
		 this.prodescription=prodescription;
	 }
	 
	 public void display(){
		 
		 System.out.println("product Name  : "+proname);
		 System.out.println("product Price : "+proprice);
		 System.out.println("Iteam Number : "+iteamnum);
		 System.out.println("Model Number : "+modelnumber);
		 System.out.println("product Category : "+procategory);
		 System.out.println("product Description : "+prodescription);
 
	 }
}